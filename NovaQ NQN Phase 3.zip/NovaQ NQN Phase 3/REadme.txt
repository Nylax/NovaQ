#Readme file 
#Team Name: NovaQ
#Team members: Nydia Assaf Aragón, Dhawal Verma, Hao Mack Yang
#Project: NeuroQuantum Nexus– Global Industry Challenge 2025

*Instalation instructions
Clone or join the Environment NovaQ Global Industry challenge (ID:novaq_yklhd0). You can use this code be3bcb93-3431-47f6-8701-6d713b79623e
Number of packages installed: 121 
You will need about 16GB of space 
Otherwise you can run the install Novaq.ipynb

First step 
open the NovaQ_Phase_3/NWB_ExPipeline_ qbraid.ipynb
You can find the nwb file load from Dandi, preprocessing, autoencoder and the quantum model in this document 
Run the cells until you reach the Quantum section and then go to step 2

Step 2 
Please ensure you run the NovaQ_Phase_3/NWB_Classical_methods.ipynb notebook BEFORE you run the quantum section in the NovaQ_Phase_3/NWB_ExPipeline_ qbraid.ipynb, since you will need the NovaQ_Phase_3/labels.npy and NovaQ_Phase_3/adj_matrix.pt files to be generated in order to run it.   
https://lab.qbraid.com/hub/user-redirect/lab/tree/NovaQ_Phase_3/NWB_ExPipeline_%20qbraid.ipynb

Step 3 Run the quantum model
Step 4 Run the #Post-Training Neuroscience Interpretation Plan

Compare 
